create schema product_s;

create table product (
product_id  int,
product_name varchar(50),
product_price decimal(5,2),
discounted_price decimal(5,2)
);
select* 
from product_s.product_table;

 

insert into products_table
value(101,"mango",200.50,150.11),
     (102,"banana",300.16,250.12),
     (103,"pawpaw",350.20,300.16),
     (104,"avocado",378.13,350.07),
     (105,"orange",400.16,380.28),
     (106,"cashew",100.18,50.02),
     (107,"carrot",600.12,550.20),
     (108,"pineapple",700.13,600.17),
     (109,"apple",400.14,780.18),
     (110,"guava",150.11,100.19);
     
alter table product;
rename table product to products_table;

select*
from products_table;

alter table products_table
modify discounted_price decimal(5,2) 
after product_name;

alter table products_table
add quantity int;

update products_table
set quantity = 20
where product_id = 101;

update products_table
set quantity = 40
where product_id = 102;

update products_table
set quantity = 60
where product_id = 103;

update products_table
set quantity = 80
where product_id = 104;

update products_table
set quantity = 100
where product_id = 105;

update products_table
set quantity = 120
where product_id = 106;

update products_table
set quantity = 140
where product_id = 107;

update products_table
set quantity = 160
where product_id = 108;

update products_table
set quantity = 180
where product_id = 109;

update products_table
set quantity = 200
where product_id = 110;
	 

select product_id, product_name
from products_table;

select*
from products_table
where  product_price between
100 and 600;

alter table products_table
drop column quantity;



