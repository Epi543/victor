-- CREATE A DATABASE --
create database classroom;

-- CREATE  TABLE EMP_DETAILS_VIEW --
create table emp_details_view(
employee_id int,
job_id int,
manager_id int,
location_id int,
first_name varchar(50),
last_name varchar(50),
salary decimal,
commission_ptc decimal,
department_name varchar(50),
job_title varchar(50),
state varchar(50),
city varchar(50),
state_province varchar(50),
country_name varchar(50),
region_name varchar(50)
);
select*
from classroom.emp_details_view;